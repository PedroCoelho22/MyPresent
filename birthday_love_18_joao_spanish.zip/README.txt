# Feliz 18º cumpleaños — João ❤️

Abre `index.html` para probar el sitio en tu ordenador.

Para publicarlo gratis:
1. Crea una cuenta en GitHub.
2. Crea un repositorio nuevo.
3. Sube `index.html`, `style.css` y `script.js`.
4. En Settings → Pages, selecciona la rama principal y la carpeta raíz.
5. Guarda y usa el enlace que GitHub te dé.

Todo el contenido romántico está en español y personalizado para João.

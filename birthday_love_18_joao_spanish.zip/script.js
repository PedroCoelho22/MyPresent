const reasons=[
["Tu sonrisa","Tu sonrisa es una de mis cosas favoritas en el mundo. Verte sonreír y saber que estás feliz hace que yo también sonría."],
["Verte feliz","No hay muchas cosas que me hagan más feliz que verte contento. Tu felicidad significa muchísimo para mí."],
["Todo en ti","Me cuesta elegir una sola cosa de ti porque, sinceramente, me encanta todo. Tu forma de ser, tu forma de hablar, tu manera de hacerme sentir... todo."],
["Eres precioso","Eres increíblemente bonito, pero lo que más me gusta es que tu belleza también está en la persona que eres."],
["Tu forma de ser","Me encanta cómo eres. No quiero que cambies para ser otra persona, porque para mí eres perfecto siendo tú."],
["Me haces feliz","Incluso un día normal puede convertirse en un buen día simplemente porque estás tú en él."],
["Puedo ser yo mismo contigo","Contigo puedo ser yo mismo sin tener que fingir nada. Poder sentirme así con alguien significa muchísimo para mí."],
["Nuestras partidas","Puede parecer una tontería, pero jugar juntos, especialmente nuestras partidas de Valorant, se ha convertido en uno de mis recuerdos favoritos contigo."],
["Nuestros momentos","No importa si estamos haciendo algo importante o simplemente jugando y diciendo tonterías. Me encanta compartir momentos contigo."],
["Me haces reír","Me encanta poder divertirnos juntos, reírnos de cualquier cosa y crear nuestros propios momentos."],
["Nuestra historia","Quién iba a decir que conocernos por Discord terminaría llevándonos hasta aquí. A veces pienso en ello y me parece increíble."],
["Tu compañía","Me gusta simplemente estar contigo. No necesito que pase nada especial para disfrutar de tenerte a mi lado."],
["Tus pequeños detalles","Hay pequeñas cosas que haces, quizá sin darte cuenta, que hacen que te quiera todavía más."],
["Me entiendes","Me encanta sentir que puedo hablar contigo, contarte cosas y compartir mi mundo contigo."],
["Eres especial","Entre tantas personas que existen, tuve la suerte de encontrarte a ti. Y para mí eres alguien verdaderamente especial."],
["Me importas muchísimo","Lo que te pasa, cómo estás y cómo te sientes me importa de verdad. Quiero verte bien y quiero estar ahí para ti."],
["Porque eres tú","No necesito una razón complicada. Te quiero porque eres tú, con todo lo que te hace ser João."],
["Porque te amo","Y esta es probablemente la razón más importante de todas: te amo muchísimo, mi amor. ❤️"]
];
const letters=[
["🥺","Ábrelo cuando estés triste","Si estás leyendo esto porque estás teniendo un mal día, recuerda que no estás solo. Estoy aquí para ti. Quiero escucharte, acompañarte y recordarte cuánto te quiero."],
["💌","Ábrelo cuando me eches de menos","Si me echas de menos ahora mismo, quiero que sepas que probablemente yo también te estoy echando de menos. Imagina que estoy contigo dándote un abrazo enorme. ❤️"],
["😴","Ábrelo cuando no puedas dormir","Ponte cómodo, respira profundamente y piensa que estamos juntos hablando de cualquier tontería hasta quedarnos dormidos. Ojalá pudiera estar ahí para darte las buenas noches en persona. 🌙"],
["🫂","Ábrelo cuando necesites un abrazo","Este es un abrazo digital de emergencia. 🫂 Si estuviera ahí contigo, te abrazaría muchísimo más fuerte y probablemente no te dejaría escapar."],
["😂","Ábrelo cuando necesites reírte","Recuerda que decidí voluntariamente enamorarme de ti y aguantar todas tus tonterías. Eso demuestra lo muchísimo que te quiero. 😂❤️"],
["❤️","Ábrelo cuando necesites recordar cuánto te amo","Te amo muchísimo, mi amor. Más de lo que muchas veces sé explicar con palabras. Eres una persona increíble y quiero que nunca olvides lo importante que eres para mí."],
["🎮","Ábrelo después de una partida horrible","Sí, quizá hayamos perdido otra partida de Valorant. Pero al menos estábamos juntos. Y eso hace que hasta perder sea divertido contigo. 😂🎮"],
["🎂","Ábrelo el día de tus 18 años","Feliz 18 cumpleaños, João, mi amor. ❤️ Hoy empieza una nueva etapa de tu vida y espero poder compartir muchísimos momentos contigo. Espero verte sonreír, jugar contigo, reírnos juntos y crear muchísimos recuerdos más. Te deseo toda la felicidad del mundo porque te la mereces. Te amo muchísimo, mi amor."]
];
const rg=document.getElementById("reasonsGrid"),lg=document.getElementById("lettersGrid"),modal=document.getElementById("modal");
rg.innerHTML=reasons.map((r,i)=>`<article class="reason-card" data-type="reason" data-index="${i}"><div class="number">RAZÓN ${String(i+1).padStart(2,"0")}</div><h3>${r[0]}</h3><p class="card-hint">Haz clic para abrir ♡</p></article>`).join("");
lg.innerHTML=letters.map((l,i)=>`<article class="letter-card" data-type="letter" data-index="${i}"><div class="letter-icon">${l[0]}</div><div><h3>${l[1]}</h3><p class="card-hint">Abrir carta →</p></div></article>`).join("");
function show(id){document.querySelectorAll(".section").forEach(s=>s.classList.remove("active"));document.getElementById(id).classList.add("active");document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.section===id));window.scrollTo({top:0,behavior:"smooth"});}
function openModal(type,i){let x=type==="reason"?reasons[i]:letters[i];document.getElementById("modalIcon").textContent=type==="reason"?"♡":x[0];document.getElementById("modalEyebrow").textContent=type==="reason"?`Razón ${String(i+1).padStart(2,"0")}`:"Una pequeña carta para ti";document.getElementById("modalTitle").textContent=type==="reason"?x[0]:x[1];document.getElementById("modalText").innerHTML=`<p>${type==="reason"?x[1]:x[2]}</p>`;modal.classList.add("open");document.body.style.overflow="hidden";}
function closeModal(){modal.classList.remove("open");document.body.style.overflow="";}
document.addEventListener("click",e=>{let n=e.target.closest("[data-section]");if(n)show(n.dataset.section);let g=e.target.closest("[data-go]");if(g)show(g.dataset.go);let c=e.target.closest("[data-type]");if(c)openModal(c.dataset.type,+c.dataset.index);if(e.target.closest(".close")||e.target.classList.contains("modal-backdrop"))closeModal();});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal();});
setInterval(()=>{let h=document.createElement("div");h.className="heart";h.textContent=Math.random()>.25?"♡":"♥";h.style.left=Math.random()*100+"vw";h.style.bottom="-30px";h.style.fontSize=10+Math.random()*18+"px";h.style.animationDuration=7+Math.random()*7+"s";document.querySelector(".hearts").appendChild(h);setTimeout(()=>h.remove(),15000)},1000);